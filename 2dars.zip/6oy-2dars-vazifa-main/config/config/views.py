from django.http import HttpRequest, HttpResponse
from django.shortcuts import render
import random

# vazifa 1
mevalar = ["Olma", "Banan", "Shaftoli", "Gilos"]

# vazifa 2
shaxs = {"ism": "Ali", "yosh": 25, "kasb": "Dasturchi"}

# vazifa 3
talabalar = [
    {"ism": "Ali", "ball": 85},
    {"ism": "Vali", "ball": 60},
    {"ism": "Salim", "ball": 90},
]

# vazifa 4
mahsulotlar = [
    {"nom": "Laptop", "narx": 1500},
    {"nom": "Telefon", "narx": 800},
    {"nom": "Sichqoncha", "narx": 30},
]

# vazifa 5
sonlar = [42, 10, 3, 98, 55, 1]
sonlar.sort()

# vazifa 6
talabalar2 = [
    {"ism": "Ali", "ball": 85},
    {"ism": "Vali", "ball": 60},
    {"ism": "Salim", "ball": 90},
]

# vazifa 7
sonlar2 = [4, 8, 15, 16, 23, 42]

# vazifa 8
odamlar = [
    {"ism": "Ali", "yosh": 25},
    {"ism": "Vali", "yosh": 30},
    {"ism": "Salim", "yosh": 28},
]
ortacha_yosh = sum(odam["yosh"] for odam in odamlar) / len(odamlar)

# vazifa 9
sonlar3 = [5, 12, 67, 89, 34, 21]

# vazifa 10
mamlakatlar = ["O‘zbekiston", "AQSh", "Rossiya", "Xitoy"]

# vazifa 11
kitoblar = [
    {"nom": "Python Asoslari", "muallif": "Guido Van Rossum"},
    {"nom": "Django Pro", "muallif": "Adrian Holovaty"},
]

# vazifa 12
ishchilar = [
    {"ism": "Ali", "maosh": 1200},
    {"ism": "Vali", "maosh": 1500},
    {"ism": "Salim", "maosh": 1800},
]
eng_yuqori_maosh = max(ishchi["maosh"] for ishchi in ishchilar)

# vaizifa 13
lotereya_sonlari = sorted(random.sample(range(1, 100), 6))

# vazifa 14
filmlar = [
    {"nom": "Inception", "yil": 2010},
    {"nom": "Interstellar", "yil": 2014},
    {"nom": "The Dark Knight", "yil": 2008},
]
eng_eski_film = min(filmlar, key=lambda f: f["yil"])
eng_yangi_film = max(filmlar, key=lambda f: f["yil"])

# vazifa 15
odamlar2 = ["Ali", "Muhammad", "Vali", "Olimjon"]
eng_uzun_soz = max(odamlar2, key=len)

def index(request: HttpRequest):
    context = {
        "fruits": mevalar,
        "person": shaxs,
        "talabalar": talabalar,
        "mahsulotlar": mahsulotlar,
        "sonlar": sonlar,
        "talabalar2": talabalar2,
        "sonlar2": sum(sonlar2),
        "ortacha_yosh": ortacha_yosh,
        "katta_son": max(sonlar3),
        "mamlakatlar": mamlakatlar,
        "kitoblar": kitoblar,
        "eng_yuqori_maosh": eng_yuqori_maosh,
        "lotereya_sonlari": lotereya_sonlari,
        "eng_eski_film": eng_eski_film,
        "eng_yangi_film": eng_yangi_film,
        "uzun_soz": eng_uzun_soz
    }
    return render(request, "index.html", context)


